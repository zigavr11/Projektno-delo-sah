<p>Prijatelj ne obstaja.</p>
