<form action="?controller=registracija&action=shrani" method="post">
<div class="form-horizontal">
    <label for="inputEmail">Ime</label>
    <input value="ziga" type="text" name="ime" class="form-control" id="exampleInputEmail1" placeholder="Ime">
  </div>
  <div class="form-group">
    <label for="inputEmail">Priimek</label>
    <input value="vodusek"  type="text" name="priimek" class="form-control" id="exampleInputEmail1" placeholder="Priimek">
  </div>
  <div class="form-group">
    <label for="inputEmail">Email address</label>
    <input value="ziga@gmail.com"  type="email" name="email" class="form-control" id="exampleInputEmail1" placeholder="Email">
  </div>
  <div class="form-group">
    <label for="inputEmail">Username</label>
    <input value="ziga"  type="text" name="username" class="form-control" id="exampleInputEmail1" placeholder="Username">
  </div>
  <div class="form-group">
    <label for="inputEmail">Password</label>
    <input value="ziga"  type="password" name="password" class="form-control" id="exampleInputEmail1" placeholder="Password">
  </div>
  <button type="submit" class="btn btn-default">Submit</button>
</form>