<h1> <a href="?controller=sah&action=ai"> Igraj proti računalniku </a></h1><p>
<h1> <a href="?controller=sah&action=friend"> Igraj proti prijatelju </a></h1><p>
<h1> <a href="?controller=sah&action=opponent"> Igraj proti naključnem igralcu </a></h1><p>