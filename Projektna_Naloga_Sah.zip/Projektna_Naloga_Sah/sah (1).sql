-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Gostitelj: 127.0.0.1
-- Čas nastanka: 29. maj 2016 ob 17.28
-- Različica strežnika: 10.1.10-MariaDB
-- Različica PHP: 5.6.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Zbirka podatkov: `sah`
--

-- --------------------------------------------------------

--
-- Struktura tabele `igra`
--

CREATE TABLE `igra` (
  `id` int(11) NOT NULL,
  `tk_uporabnik1` int(11) NOT NULL,
  `tk_uporabnik2` int(11) NOT NULL COMMENT '-1 -> lahek AI, -2 ->srednjiAI, -3 ->tezkiAI',
  `zmagovalec` int(11) NOT NULL COMMENT '-1 -> AI',
  `tip` varchar(100) COLLATE utf32_slovenian_ci NOT NULL COMMENT 'f -> friendly, a -> ai, o -> oponnent',
  `stanje` varchar(10) COLLATE utf32_slovenian_ci NOT NULL COMMENT 'l -> live, e -> end(game ended)'
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_slovenian_ci;

--
-- Odloži podatke za tabelo `igra`
--

INSERT INTO `igra` (`id`, `tk_uporabnik1`, `tk_uporabnik2`, `zmagovalec`, `tip`, `stanje`) VALUES
(21, 1, 2, 2, 'f', 'e'),
(22, 3, 1, 1, 'f', 'e'),
(23, 1, 2, 1, 'f', 'e'),
(24, 1, 2, 1, 'f', 'e'),
(25, 1, 2, 2, 'f', 'e'),
(26, 2, 1, 1, 'f', 'e'),
(27, 2, 1, 2, 'f', 'e'),
(28, 2, 1, 2, 'f', 'e'),
(29, 2, 1, 2, 'f', 'e');

-- --------------------------------------------------------

--
-- Struktura tabele `izziv`
--

CREATE TABLE `izziv` (
  `id_uporabnika` int(11) NOT NULL,
  `id_prijatelja` int(11) NOT NULL,
  `stanje` varchar(10) COLLATE utf32_slovenian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_slovenian_ci;

--
-- Odloži podatke za tabelo `izziv`
--

INSERT INTO `izziv` (`id_uporabnika`, `id_prijatelja`, `stanje`) VALUES
(1, 2, 'a'),
(1, 3, 'a');

-- --------------------------------------------------------

--
-- Struktura tabele `prijatelji`
--

CREATE TABLE `prijatelji` (
  `id_uporabnika` int(11) NOT NULL,
  `id_prijatelja` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_slovenian_ci;

--
-- Odloži podatke za tabelo `prijatelji`
--

INSERT INTO `prijatelji` (`id_uporabnika`, `id_prijatelja`) VALUES
(1, 2),
(1, 3),
(1, 4),
(1, 5),
(2, 1);

-- --------------------------------------------------------

--
-- Struktura tabele `stanja`
--

CREATE TABLE `stanja` (
  `id` int(11) NOT NULL,
  `stanje` varchar(1024) COLLATE utf32_slovenian_ci NOT NULL,
  `poteza` varchar(10) COLLATE utf32_slovenian_ci NOT NULL COMMENT 'kdo je na vrsti b-> black, w->white',
  `sah` int(11) NOT NULL COMMENT '-1 -> no check 1-> check',
  `tk_igra` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_slovenian_ci;

--
-- Odloži podatke za tabelo `stanja`
--

INSERT INTO `stanja` (`id`, `stanje`, `poteza`, `sah`, `tk_igra`) VALUES
(18, 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR', 'w', 0, 21),
(26, 'rnbqkbnr/pppppppp/8/8/8/3P4/PPP1PPPP/RNBQKBNR', 'b', 0, 21),
(27, 'rnbqkbnr/ppp1pppp/3p4/8/8/3P4/PPP1PPPP/RNBQKBNR', 'w', 0, 21),
(28, 'rnbqkbnr/ppp1pppp/3p4/8/8/3PP3/PPP2PPP/RNBQKBNR', 'b', 0, 21),
(29, 'rnbqkbnr/ppp1pppp/3p4/8/8/3PPP2/PPP3PP/RNBQKBNR', 'w', 0, 21),
(31, 'rnbqkbnr/ppp1pppp/3p4/8/5P2/3PP3/PPP3PP/RNBQKBNR', 'b', 0, 21),
(32, 'rnbqkbnr/ppp1pppp/3p4/7Q/5P2/3PP3/PPP3PP/RNB1KBNR', 'w', 0, 21),
(33, 'rnbqkbnr/ppp1pppp/3p4/7Q/5P2/3PPN2/PPP3PP/RNB1KB1R', 'b', 0, 21),
(34, 'rnbqkbnr/ppp1pppp/3p4/7Q/3N1P2/3PP3/PPP3PP/RNB1KB1R', 'w', 0, 21),
(35, 'rnbqkbnr/ppp1pppp/3p4/7Q/3N1P2/3PP3/PPP1B1PP/RNB1K2R', 'b', 0, 21),
(36, 'rnbqkbnr/ppp1pppp/3p4/1N5Q/5P2/3PP3/PPP1B1PP/RNB1K2R', 'w', 0, 21),
(37, 'rnbqkbnr/ppp1pppp/3N4/7Q/5P2/3PP3/PPP1B1PP/RNB1K2R', 'b', 0, 21),
(38, 'rnbqNbnr/ppp1pppp/8/7Q/5P2/3PP3/PPP1B1PP/RNB1K2R', 'w', 0, 21),
(39, 'rnbq1bnr/ppN1pppp/8/7Q/5P2/3PP3/PPP1B1PP/RNB1K2R', 'b', 0, 21),
(40, 'Nnbq1bnr/pp2pppp/8/7Q/5P2/3PP3/PPP1B1PP/RNB1K2R', 'w', 0, 21),
(41, '1nbq1bnr/pp2pppp/1N6/7Q/5P2/3PP3/PPP1B1PP/RNB1K2R', 'b', 0, 21),
(42, '1nbq1bnr/pp2pppp/8/7Q/2N2P2/3PP3/PPP1B1PP/RNB1K2R', 'w', 0, 21),
(43, '1nbq1bnr/pp2pppp/8/6Q1/2N2P2/3PP3/PPP1B1PP/RNB1K2R', 'b', 0, 21),
(44, '1nbq1bnr/pp2pppp/8/5Q2/2N2P2/3PP3/PPP1B1PP/RNB1K2R', 'w', 0, 21),
(45, '1nbq1bnr/pp2pppp/8/4Q3/2N2P2/3PP3/PPP1B1PP/RNB1K2R', 'b', 0, 21),
(46, '1nbq1bnr/pp2pppp/8/3Q4/2N2P2/3PP3/PPP1B1PP/RNB1K2R', 'w', 0, 21),
(47, '1nbq1bnr/pp2pppp/8/2Q5/2N2P2/3PP3/PPP1B1PP/RNB1K2R', 'b', 0, 21),
(48, '1nbq1bnr/pp2pppp/8/1Q6/2N2P2/3PP3/PPP1B1PP/RNB1K2R', 'w', 0, 21),
(49, '1nbq1bnr/pp2pppp/8/8/2N2P2/1Q1PP3/PPP1B1PP/RNB1K2R', 'b', 0, 21),
(50, '1nbq1bnr/pp2pppp/8/8/1QN2P2/3PP3/PPP1B1PP/RNB1K2R', 'w', 0, 21),
(51, '1nbq1bnr/pp2pppp/8/8/Q1N2P2/3PP3/PPP1B1PP/RNB1K2R', 'b', 0, 21),
(52, '1nbq1bnr/pp2pppp/8/Q7/2N2P2/3PP3/PPP1B1PP/RNB1K2R', 'w', 0, 21),
(53, '1nbq1bnr/pp2pppp/8/1Q6/2N2P2/3PP3/PPP1B1PP/RNB1K2R', 'b', 0, 21),
(54, '1nbq1bnr/pp2pppp/8/2Q5/2N2P2/3PP3/PPP1B1PP/RNB1K2R', 'w', 0, 21),
(55, '1nbq1bnr/pp2pppp/8/3Q4/2N2P2/3PP3/PPP1B1PP/RNB1K2R', 'b', 0, 21),
(56, '1nbq1bnr/pp2pppp/8/4Q3/2N2P2/3PP3/PPP1B1PP/RNB1K2R', 'w', 0, 21),
(57, '1nbq1bnr/pp2pppp/8/3Q4/2N2P2/3PP3/PPP1B1PP/RNB1K2R', 'b', 0, 21),
(58, '1nbq1bnr/pp2pppp/8/2Q5/2N2P2/3PP3/PPP1B1PP/RNB1K2R', 'w', 0, 21),
(59, '1nbq1bnr/pp2pppp/8/1Q6/2N2P2/3PP3/PPP1B1PP/RNB1K2R', 'b', 0, 21),
(60, '1nbq1bnr/pp2pppp/8/2Q5/2N2P2/3PP3/PPP1B1PP/RNB1K2R', 'w', 0, 21),
(61, '1nbq1bnr/pp2pppp/8/3Q4/2N2P2/3PP3/PPP1B1PP/RNB1K2R', 'b', 0, 21),
(62, '1nb2bnr/ppq1pppp/8/3Q4/2N2P2/3PP3/PPP1B1PP/RNB1K2R', 'w', 0, 21),
(63, '1nb2bnr/pp2pppp/3q4/3Q4/2N2P2/3PP3/PPP1B1PP/RNB1K2R', 'b', 0, 21),
(64, '1nb2bnr/pp2pppp/3q4/1Q6/2N2P2/3PP3/PPP1B1PP/RNB1K2R', 'w', 0, 21),
(65, '1nb2bnr/pp2pppp/3q4/2Q5/2N2P2/3PP3/PPP1B1PP/RNB1K2R', 'b', 0, 21),
(66, '1nb2bnr/pp2pppp/3q4/1Q6/2N2P2/3PP3/PPP1B1PP/RNB1K2R', 'w', 0, 21),
(67, '1nb2bnr/pp2pppp/2q5/1Q6/2N2P2/3PP3/PPP1B1PP/RNB1K2R', 'b', 0, 21),
(68, '1nb2bnr/pp2pppp/3q4/1Q6/2N2P2/3PP3/PPP1B1PP/RNB1K2R', 'w', 0, 21),
(69, '1nb2bnr/pp2pppp/8/1Q1q4/2N2P2/3PP3/PPP1B1PP/RNB1K2R', 'b', 0, 21),
(70, '1nb2bnr/pp2pppp/3N4/1Q1q4/5P2/3PP3/PPP1B1PP/RNB1K2R', 'w', 0, 21),
(71, '1nb2bnr/pp2pppp/8/1Q1q4/4NP2/3PP3/PPP1B1PP/RNB1K2R', 'b', 0, 21),
(72, '1nb2bnr/pp2pppp/8/1Q1q4/3PNP2/4P3/PPP1B1PP/RNB1K2R', 'w', 0, 21),
(73, '1nb2bnr/pp2pppp/2q5/1Q6/3PNP2/4P3/PPP1B1PP/RNB1K2R', 'b', 0, 21),
(74, '1nb2bnr/pp2pppp/2q5/1Q6/3PNP2/2P1P3/PP2B1PP/RNB1K2R', 'w', 0, 21),
(75, '1nb2bnr/pp2pppp/2q5/8/1Q1PNP2/2P1P3/PP2B1PP/RNB1K2R', 'b', 0, 21),
(76, '1nb2bnr/pp2pppp/8/3q4/1Q1PNP2/2P1P3/PP2B1PP/RNB1K2R', 'w', 0, 21),
(77, '1nb2bnr/pp2pppp/8/2Nq4/1Q1P1P2/2P1P3/PP2B1PP/RNB1K2R', 'b', 0, 21),
(78, '1nb2bnr/pp2pppp/4N3/3q4/1Q1P1P2/2P1P3/PP2B1PP/RNB1K2R', 'w', 0, 21),
(79, '1nb2bnr/pp2pppp/4N3/4q3/1Q1P1P2/2P1P3/PP2B1PP/RNB1K2R', 'b', 0, 21),
(80, '1nb2bnr/pp2pppp/4N3/4qP2/1Q1P4/2P1P3/PP2B1PP/RNB1K2R', 'w', 0, 21),
(81, '1nb2bnr/pp2pp1p/4N1p1/4qP2/1Q1P4/2P1P3/PP2B1PP/RNB1K2R', 'b', 0, 21),
(82, '1nb2bnr/pp2pp1p/4N1p1/4qP2/1Q1P4/P1P1P3/1P2B1PP/RNB1K2R', 'w', 0, 21),
(83, '2b2bnr/pp2pp1p/2n1N1p1/4qP2/1Q1P4/P1P1P3/1P2B1PP/RNB1K2R', 'b', 0, 21),
(84, '2b2bnr/pp2pp1p/2n1N1p1/4qP2/1Q1P4/P1P1P3/1P1BB1PP/RN2K2R', 'w', 0, 21),
(85, '2b2bnr/p3pp1p/1pn1N1p1/4qP2/1Q1P4/P1P1P3/1P1BB1PP/RN2K2R', 'b', 0, 21),
(86, '2b2bnr/p3pp1p/1pn1N1p1/4qP2/1Q1PP3/P1P5/1P1BB1PP/RN2K2R', 'w', 0, 21),
(87, '2b2bnr/p3pp1p/2n1N1p1/1p2qP2/1Q1PP3/P1P5/1P1BB1PP/RN2K2R', 'b', 0, 21),
(88, '2b2bnr/p3pp1p/2n1N1p1/1p2PP2/1Q1P4/P1P5/1P1BB1PP/RN2K2R', 'w', 0, 21),
(89, '2b2bnr/p3p2p/2n1Npp1/1p2PP2/1Q1P4/P1P5/1P1BB1PP/RN2K2R', 'b', 0, 21),
(90, 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR', 'w', 0, 22),
(91, 'rnbqkbnr/ppp1pppp/3p4/8/8/8/PPPPPPPP/RNBQKBNR', 'b', 0, 22),
(92, 'rnbqkbnr/ppp1pppp/3p4/8/8/3P4/PPP1PPPP/RNBQKBNR', 'w', 0, 22),
(93, 'rnbqkbnr/ppp1pppp/8/3p4/8/3P4/PPP1PPPP/RNBQKBNR', 'b', 0, 22),
(94, 'rnbqkbnr/ppp1pppp/8/3p4/3P4/8/PPP1PPPP/RNBQKBNR', 'w', 0, 22),
(95, 'rnbqkbnr/ppp2ppp/4p3/3p4/3P4/8/PPP1PPPP/RNBQKBNR', 'b', 0, 22),
(96, 'rnbqkbnr/ppp2ppp/4p3/3p4/3P4/4P3/PPP2PPP/RNBQKBNR', 'w', 0, 22),
(97, 'rnbqkbnr/ppp2ppp/8/3pp3/3P4/4P3/PPP2PPP/RNBQKBNR', 'b', 0, 22),
(98, 'rnbqkbnr/ppp2ppp/8/3pp3/3PP3/8/PPP2PPP/RNBQKBNR', 'w', 0, 22),
(99, 'rnbqkbnr/ppp2ppp/8/3p4/3pP3/8/PPP2PPP/RNBQKBNR', 'b', 0, 22),
(100, 'rnbqkbnr/ppp2ppp/8/3P4/3p4/8/PPP2PPP/RNBQKBNR', 'w', 0, 22),
(101, 'rnbqkbnr/ppp2ppp/8/3P4/8/3p4/PPP2PPP/RNBQKBNR', 'b', 0, 22),
(102, 'rnbqkbnr/ppp2ppp/8/3P4/8/3P4/PP3PPP/RNBQKBNR', 'w', 0, 22),
(103, 'rn1qkbnr/ppp2ppp/8/3P1b2/8/3P4/PP3PPP/RNBQKBNR', 'b', 0, 22),
(104, 'rn1qkbnr/ppp2ppp/8/3P1b2/8/3P4/PP2BPPP/RNBQK1NR', 'w', 0, 22),
(105, 'rn2kbnr/ppp2ppp/8/3P1b2/7q/3P4/PP2BPPP/RNBQK1NR', 'b', 0, 22),
(106, 'rn2kbnr/ppp2ppp/8/3P1b2/7q/3P4/PP1QBPPP/RNB1K1NR', 'w', 0, 22),
(107, 'rn1qkbnr/ppp2ppp/8/3P1b2/8/3P4/PP1QBPPP/RNB1K1NR', 'b', 0, 22),
(108, 'rn1qkbnr/ppp2ppp/8/3P1b2/1Q6/3P4/PP2BPPP/RNB1K1NR', 'w', 0, 22),
(109, 'rn1qkbnr/ppp2ppp/8/3P4/1Q4b1/3P4/PP2BPPP/RNB1K1NR', 'b', 0, 22),
(110, 'rn1qkbnr/ppp2ppp/8/3P4/6b1/3P4/PP1QBPPP/RNB1K1NR', 'w', 0, 22),
(111, 'rn1qkbnr/pp3ppp/2p5/3P4/6b1/3P4/PP1QBPPP/RNB1K1NR', 'b', 0, 22),
(112, 'rn1qkbnr/pp3ppp/2p5/3P4/5Qb1/3P4/PP2BPPP/RNB1K1NR', 'w', 0, 22),
(113, 'rn1qkbnr/pp3p1p/2p5/3P2p1/5Qb1/3P4/PP2BPPP/RNB1K1NR', 'b', 0, 22),
(114, 'rn1qkbnr/pp3p1p/2p5/3P2p1/5QB1/3P4/PP3PPP/RNB1K1NR', 'w', 0, 22),
(115, 'rn1qkbnr/pp3p1p/2p5/3P4/5pB1/3P4/PP3PPP/RNB1K1NR', 'b', 0, 22),
(116, 'rn1qkbnr/pp3p1p/2P5/8/5pB1/3P4/PP3PPP/RNB1K1NR', 'w', 0, 22),
(117, 'rn1qkbnr/pp3p1p/2P5/8/6B1/3P1p2/PP3PPP/RNB1K1NR', 'b', 0, 22),
(118, 'rn1qkbnr/pp1B1p1p/2P5/8/8/3P1p2/PP3PPP/RNB1K1NR', 'w', 0, 22),
(119, 'rn2kbnr/pp1q1p1p/2P5/8/8/3P1p2/PP3PPP/RNB1K1NR', 'b', 0, 22),
(120, 'rn2kbnr/pp1P1p1p/8/8/8/3P1p2/PP3PPP/RNB1K1NR', 'w', 0, 22),
(121, 'rn3bnr/pp1k1p1p/8/8/8/3P1p2/PP3PPP/RNB1K1NR', 'b', 0, 22),
(122, 'rn3bnr/pp1k1p1p/8/8/8/2NP1p2/PP3PPP/R1B1K1NR', 'w', 0, 22),
(123, 'rn3bnr/pp3p1p/3k4/8/8/2NP1p2/PP3PPP/R1B1K1NR', 'b', 0, 22),
(124, 'rn3bnr/pp3p1p/3k4/1N6/8/3P1p2/PP3PPP/R1B1K1NR', 'w', 0, 22),
(125, 'rn3bnr/ppk2p1p/8/1N6/8/3P1p2/PP3PPP/R1B1K1NR', 'b', 0, 22),
(126, 'rn3bnr/ppk2p1p/8/1N6/5B2/3P1p2/PP3PPP/R3K1NR', 'w', 1, 22),
(127, 'rn3bnr/pp1k1p1p/8/1N6/5B2/3P1p2/PP3PPP/R3K1NR', 'b', 0, 22),
(128, 'rn3bnr/pp1k1p1p/8/1N6/3P1B2/5p2/PP3PPP/R3K1NR', 'w', 0, 22),
(129, 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR', 'w', 0, 23),
(130, 'rnbqkbnr/pppp1ppp/8/4p3/8/8/PPPPPPPP/RNBQKBNR', 'b', 0, 23),
(131, 'rnbqkbnr/pppp1ppp/8/4p3/3P4/8/PPP1PPPP/RNBQKBNR', 'w', 0, 23),
(132, 'rnbqkbnr/pppp1ppp/8/8/3p4/8/PPP1PPPP/RNBQKBNR', 'b', 0, 23),
(133, 'rnbqkbnr/pppp1ppp/8/8/3Q4/8/PPP1PPPP/RNB1KBNR', 'w', 0, 23),
(134, 'rnb1kbnr/pppp1ppp/8/6q1/3Q4/8/PPP1PPPP/RNB1KBNR', 'b', 0, 23),
(135, 'rnb1kbnr/pppp1ppp/8/6q1/5Q2/8/PPP1PPPP/RNB1KBNR', 'w', 0, 23),
(136, 'rnb1kbnr/pppp1ppp/8/8/5q2/8/PPP1PPPP/RNB1KBNR', 'b', 0, 23),
(137, 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR', 'w', 0, 24),
(138, 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR', 'w', 0, 25),
(139, 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR', 'w', 0, 26),
(140, 'rnbqkbnr/ppp1pppp/3p4/8/8/8/PPPPPPPP/RNBQKBNR', 'b', 0, 26),
(141, 'rnbqkbnr/ppp1pppp/3p4/8/8/3P4/PPP1PPPP/RNBQKBNR', 'w', 0, 26),
(142, 'rnb1kbnr/pppqpppp/3p4/8/8/3P4/PPP1PPPP/RNBQKBNR', 'b', 0, 26),
(143, 'rnb1kbnr/pppqpppp/3p4/8/8/3P4/PPPQPPPP/RNB1KBNR', 'w', 0, 26),
(144, 'rnb1kbnr/pppqpppp/8/3p4/8/3P4/PPPQPPPP/RNB1KBNR', 'b', 0, 26),
(145, 'rnb1kbnr/pppqpppp/8/3p2Q1/8/3P4/PPP1PPPP/RNB1KBNR', 'w', 0, 26),
(146, 'rnb1kbnr/pppq1ppp/4p3/3p2Q1/8/3P4/PPP1PPPP/RNB1KBNR', 'b', 0, 26),
(147, 'rnb1kbnr/pppqQppp/4p3/3p4/8/3P4/PPP1PPPP/RNB1KBNR', 'w', 1, 26),
(148, 'rnb1k1nr/pppqbppp/4p3/3p4/8/3P4/PPP1PPPP/RNB1KBNR', 'b', 0, 26),
(149, 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR', 'w', 0, 27),
(150, 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR', 'w', 0, 28),
(151, 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR', 'w', 0, 29);

-- --------------------------------------------------------

--
-- Struktura tabele `uporabnik`
--

CREATE TABLE `uporabnik` (
  `id` int(11) NOT NULL,
  `prijava` int(11) NOT NULL,
  `ime` varchar(1024) COLLATE utf32_slovenian_ci NOT NULL,
  `priimek` varchar(1024) COLLATE utf32_slovenian_ci NOT NULL,
  `uporabnisko_ime` varchar(1024) COLLATE utf32_slovenian_ci NOT NULL,
  `geslo` varchar(1024) COLLATE utf32_slovenian_ci NOT NULL,
  `rating` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_slovenian_ci;

--
-- Odloži podatke za tabelo `uporabnik`
--

INSERT INTO `uporabnik` (`id`, `prijava`, `ime`, `priimek`, `uporabnisko_ime`, `geslo`, `rating`) VALUES
(1, 1, 'ziga', 'vodusek', 'ziga', 'c18416076e742bd8f5af313875a290f74b4b1b81fb0e6c8d46b26bc193510d88', 0),
(2, 1, 'zan', 'pevec', 'zan', 'd6bdb7c3e5a7898117db4ac6c1d429fcf389028aad8604a135b977be57187113', 0),
(3, -1, 'tomaz', 'resnik', 'resnik', '188e82262b579f612ed255f7e4771f22c655471ea3d98d095f08dc8f82646920', 0),
(4, 0, 'test2', 'test2', 'test2', '60303ae22b998861bce3b28f33eec1be758a213c86c93c076dbe9f558c11c752', 0),
(5, -1, 'test3', 'test3', 'test3', 'fd61a03af4f77d870fc21e05e7e80678095c92d808cfb3b5c279ee04c74aca13', 0);

--
-- Indeksi zavrženih tabel
--

--
-- Indeksi tabele `igra`
--
ALTER TABLE `igra`
  ADD PRIMARY KEY (`id`);

--
-- Indeksi tabele `izziv`
--
ALTER TABLE `izziv`
  ADD PRIMARY KEY (`id_uporabnika`,`id_prijatelja`);

--
-- Indeksi tabele `prijatelji`
--
ALTER TABLE `prijatelji`
  ADD PRIMARY KEY (`id_uporabnika`,`id_prijatelja`);

--
-- Indeksi tabele `stanja`
--
ALTER TABLE `stanja`
  ADD PRIMARY KEY (`id`);

--
-- Indeksi tabele `uporabnik`
--
ALTER TABLE `uporabnik`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT zavrženih tabel
--

--
-- AUTO_INCREMENT tabele `igra`
--
ALTER TABLE `igra`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT tabele `stanja`
--
ALTER TABLE `stanja`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=152;
--
-- AUTO_INCREMENT tabele `uporabnik`
--
ALTER TABLE `uporabnik`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
